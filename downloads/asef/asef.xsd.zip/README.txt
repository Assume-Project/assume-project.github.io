The ASSUME Static Code Analysis Tool Exchange Format repository
---------------------------------------------------------------

* The root element of the configuration XML schema is defined in ASC3F.xsd.
  (ASC3F="ASSUME Static Code analysis tool Common Configuration Format")

* The root element of the report XML schema is defined in ASCCRF.xsd.
  (ASCCRF="ASSUME Static Code analysis tool Common Report Format")
	
* The structure of the schema modules is presented in doc/SchemaModuleStructure.pdf.

* An example configuration is given in ExampleConfiguration.xml and ExampleReport.xml,
  with a detailed explanation given in doc/ExampleConfigurationGuide.pdf.
